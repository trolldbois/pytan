
Tanium Sensor Analysis Tool
===========================

This tool is a statically compiled version of the PyTan toolset
which will ask a question for every single sensor that exists
in the Tanium Server.

Modify CONFIG.bat according to your needs, then use RUN.bat to
execute. Alternatively, just run Tanium_Sensor_Analysis_Tool.exe
directly.
