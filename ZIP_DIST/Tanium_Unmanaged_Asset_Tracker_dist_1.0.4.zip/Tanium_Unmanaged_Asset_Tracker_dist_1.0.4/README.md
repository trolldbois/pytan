
Tanium Unmanaged Asset Tracker
===========================

This tool is a statically compiled windows EXE version of a
python script in the PyTan toolset.

It is used to get all managed clients from Tanium, then get all
unmanaged assets results, and cull out the truly managed assets
from the results of unmanaged assets and produce a CSV report of
"Truly" unmanaged assets.

Modify CONFIG.bat according to your needs, then use RUN.bat to
execute. Alternatively, just run Tanium_Unmanaged_Asset_Tracker.exe
directly.
