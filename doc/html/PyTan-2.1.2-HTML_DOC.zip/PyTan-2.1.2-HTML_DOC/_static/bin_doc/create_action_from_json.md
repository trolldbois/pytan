Create Action From JSON Readme
===========================

---------------------------
<a name='toc'>Table of contents:</a>

  * [Help for Create Action From JSON](#user-content-help-for-create-action-from-json)
  * [Export action id 1 as JSON](#user-content-export-action-id-1-as-json)
  * [Change name or url_regex in the JSON](#user-content-change-name-or-url_regex-in-the-json)
  * [Create a new action from the modified JSON file](#user-content-create-a-new-action-from-the-modified-json-file)

---------------------------

# Help for Create Action From JSON

  * Print the help for create_action_from_json.py
  * All scripts in bin/ will supply help if -h is on the command line
  * If passing in a parameter with a space or a special character, you need to surround it with quotes properly. On Windows this means double quotes. On Linux/Mac, this means single or double quotes, depending on what kind of character escaping you need.
  * If running this script on Linux or Mac, use the python scripts directly as the bin/create_action_from_json.py
  * If running this script on Windows, use the batch script in the winbin/create_action_from_json.bat so that python is called correctly.

```bash
create_action_from_json.py -h
```

```
usage: create_action_from_json.py [-h] [-u USERNAME] [-p PASSWORD]
                                  [--session_id SESSION_ID] [--host HOST]
                                  [--port PORT] [-l LOGLEVEL] [--debugformat]
                                  [--record_all_requests]
                                  [--stats_loop_enabled] [--http_auth_retry]
                                  [--http_retry_count HTTP_RETRY_COUNT] -j
                                  JSON_FILE

Create an object of type: action from a JSON file

optional arguments:
  -h, --help            show this help message and exit

Handler Authentication:
  -u USERNAME, --username USERNAME
                        Name of user (default: None)
  -p PASSWORD, --password PASSWORD
                        Password of user (default: None)
  --session_id SESSION_ID
                        Session ID to authenticate with instead of
                        username/password (default: None)
  --host HOST           Hostname/ip of SOAP Server (default: None)
  --port PORT           Port to use when connecting to SOAP Server (default:
                        443)

Handler Options:
  -l LOGLEVEL, --loglevel LOGLEVEL
                        Logging level to use, increase for more verbosity
                        (default: 0)
  --debugformat         Enable debug format for logging (default: False)
  --record_all_requests
                        Record all requests in
                        handler.session.ALL_REQUESTS_RESPONSES (default:
                        False)
  --stats_loop_enabled  Enable the statistics loop (default: False)
  --http_auth_retry     Disable retry on HTTP authentication failures
                        (default: True)
  --http_retry_count HTTP_RETRY_COUNT
                        Retry count for HTTP failures/invalid responses
                        (default: 5)

Create Action from JSON Options:
  -j JSON_FILE, --json JSON_FILE
                        JSON file to use for creating the object (default: )
```

  * Validation Test: exitcode
    * Valid: **True**
    * Messages: Exit Code is 0

  * Validation Test: noerror
    * Valid: **True**
    * Messages: No error texts found in stderr/stdout



[TOC](#user-content-toc)


# Export action id 1 as JSON

  * Get the first action object
  * Save the results to a JSON file

```bash
bin/get_action.py -u Administrator -p 'Tanium2015!' --host 10.0.1.240 --loglevel 1 --id 1 --file "/tmp/out.json" --export_format json
```

```
PyTan v2.1.0 Handler for Session to 10.0.1.240:443, Authenticated: True, Platform Version: 6.5.314.4301
Found items:  ActionList, len: 1
Report file '/tmp/out.json' written with 1302 bytes
```

  * Validation Test: exitcode
    * Valid: **True**
    * Messages: Exit Code is 0

  * Validation Test: file_exist_contents
    * Valid: **True**
    * Messages: File /tmp/out.json exists, content:

```
{
  "_type": "actions", 
  "action": [
    {
      "_type": "action", 
      "action_group": {
        "_type": "group", 
        "id": 0, 
        "name": "Default"
      }, 
...trimmed for brevity...
```

  * Validation Test: noerror
    * Valid: **True**
    * Messages: No error texts found in stderr/stdout



[TOC](#user-content-toc)


# Change name or url_regex in the JSON

  * Add CMDLINE TEST to name or url_regex in the JSON file

```bash
perl -p -i -e 's/^(      "(name|url_regex)": ".*)"/$1 CMDLINE TEST 7675"/gm' /tmp/out.json && cat /tmp/out.json
```

```
{
  "_type": "actions", 
  "action": [
    {
      "_type": "action", 
      "action_group": {
        "_type": "group", 
        "id": 0, 
        "name": "Default"
      }, 
      "approver": {
        "_type": "user", 
        "id": 1, 
        "name": "Administrator"
      }, 
      "comment": "Distribute Tanium Standard Utilities", 
      "creation_time": "2015-08-26T20:14:40", 
      "distribute_seconds": 3200, 
      "expire_seconds": 3300, 
      "history_saved_question": {
        "_type": "saved_question", 
        "id": 102
      }, 
      "id": 1, 
      "name": "Distribute Tanium Standard Utilities CMDLINE TEST 7675", 
      "package_spec": {
        "_type": "package_spec", 
        "command": "cmd /c cscript install-standard-utils.vbs \"Tools\\StdUtils\"", 
        "id": 20, 
        "name": "Distribute Tanium Standard Utilities"
      }, 
      "saved_action": {
        "_type": "saved_action", 
        "id": 1
      }, 
      "skip_lock_flag": 0, 
      "status": "Pending", 
      "stopped_flag": 1, 
      "target_group": {
        "_type": "group", 
        "id": 37, 
        "name": "Default"
      }, 
      "user": {
        "_type": "user", 
        "group_id": 0, 
        "id": 1, 
        "last_login": "2015-09-04T01:49:57", 
        "name": "Administrator"
      }
    }
  ]
}
```

  * Validation Test: exitcode
    * Valid: **True**
    * Messages: Exit Code is 0

  * Validation Test: file_exist
    * Valid: **True**
    * Messages: File /tmp/out.json exists

  * Validation Test: noerror
    * Valid: **True**
    * Messages: No error texts found in stderr/stdout



[TOC](#user-content-toc)


# Create a new action from the modified JSON file

```bash
bin/create_action_from_json.py -u Administrator -p 'Tanium2015!' --host 10.0.1.240 --loglevel 1 -j "/tmp/out.json"
```

```
PyTan v2.1.0 Handler for Session to 10.0.1.240:443, Authenticated: True, Platform Version: 6.5.314.4301
Created item: Action, name: 'Distribute Tanium Standard Utilities CMDLINE TEST 7675', id: 512, ID: 512
```

  * Validation Test: exitcode
    * Valid: **True**
    * Messages: Exit Code is 0

  * Validation Test: noerror
    * Valid: **True**
    * Messages: No error texts found in stderr/stdout



[TOC](#user-content-toc)


###### generated by: `build_bin_doc v2.1.0`, date: Thu Sep  3 21:50:17 2015 EDT, Contact info: **Jim Olsen <jim.olsen@tanium.com>**